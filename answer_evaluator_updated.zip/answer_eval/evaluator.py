"""
Evaluator
---------
Strategy:
  - MCQ        → regex-based exact match, fast, no API
  - Theory     → keyword matching (local) + semantic scoring via sentence-transformers
  - Code       → Groq LLM (free tier: 30 req/min, 6000 tokens/min on llama3-8b)
  - Short Ans  → keyword + semantic similarity

Groq is used ONLY for code evaluation and as an enhancement for theory.
It's free (https://console.groq.com) with generous limits.
"""

import os
import re
import json
from typing import Optional

# ── Optional imports (graceful fallback if not installed) ──────────────────────
try:
    from sentence_transformers import SentenceTransformer, util
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

try:
    from groq import Groq
    _GROQ_AVAILABLE = True
except ImportError:
    import subprocess, sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "groq", "-q"])
    try:
        from groq import Groq
        _GROQ_AVAILABLE = True
    except ImportError:
        _GROQ_AVAILABLE = False

import streamlit as st

# ── Model cache (load once per session) ───────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_sentence_model():
    """Load a small, fast sentence embedding model."""
    if _ST_AVAILABLE:
        return SentenceTransformer("all-MiniLM-L6-v2")
    return None


def get_groq_client() -> Optional[object]:
    """Get Groq client using API key from Streamlit secrets or env var."""
    if not _GROQ_AVAILABLE:
        return None
    # Try secrets.toml first, then environment variable
    api_key = ""
    try:
        api_key = st.secrets["GROQ_API_KEY"]
    except Exception:
        pass
    if not api_key:
        api_key = os.environ.get("GROQ_API_KEY", "")
    if not api_key or api_key.strip() == "your_groq_api_key_here":
        return None
    return Groq(api_key=api_key.strip())


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN EVALUATION ROUTER
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_answer(
    student_text: str,
    reference: str,
    answer_type: str,
    subject: str = "",
    total_marks: int = 10
) -> dict:
    """
    Route to the right evaluator based on answer_type.
    Returns a unified results dict consumed by result_renderer.
    """
    student_text = student_text.strip()
    reference = reference.strip()

    base = {
        "answer_type": answer_type,
        "subject": subject,
        "total_marks": total_marks,
        "student_text": student_text,
        "reference": reference,
        "word_count": len(student_text.split()),
        "char_count": len(student_text),
    }

    if answer_type == "MCQ (Multiple Choice)":
        result = evaluate_mcq(student_text, reference, total_marks)
    elif answer_type == "Theory / Descriptive":
        result = evaluate_theory(student_text, reference, total_marks)
    elif answer_type == "Code / Programming":
        result = evaluate_code(student_text, reference, total_marks, subject)
    else:  # Short Answer
        result = evaluate_short(student_text, reference, total_marks)

    return {**base, **result}


# ══════════════════════════════════════════════════════════════════════════════
#  MCQ EVALUATOR
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_mcq(student_text: str, answer_key: str, total_marks: int) -> dict:
    """
    Parse answer key like '1-A 2-C 3-B' and student answers from extracted text.
    """
    def parse_answers(text: str) -> dict:
        # Match patterns like: 1-A, 1.A, 1) A, Q1:A, 1 A
        pattern = r"(?:Q?|question\s*)(\d+)\s*[-.):\s]\s*([A-Ea-e])"
        matches = re.findall(pattern, text, re.IGNORECASE)
        return {int(q): ans.upper() for q, ans in matches}

    correct_map = parse_answers(answer_key)
    student_map = parse_answers(student_text)

    if not correct_map:
        return {
            "score": 0,
            "percentage": 0,
            "grade": "N/A",
            "error": "Could not parse the answer key. Use format: 1-A 2-C 3-B",
            "mcq_details": [],
            "feedback": "Please format the answer key as: 1-A, 2-B, 3-C etc.",
            "strengths": [],
            "improvements": ["Reformat the answer key"],
            "keyword_analysis": {}
        }

    details = []
    correct_count = 0
    total_q = len(correct_map)

    for q_num, correct_ans in sorted(correct_map.items()):
        student_ans = student_map.get(q_num, "?")
        is_correct = student_ans == correct_ans
        if is_correct:
            correct_count += 1
        details.append({
            "question": q_num,
            "student": student_ans,
            "correct": correct_ans,
            "is_correct": is_correct
        })

    marks_per_q = total_marks / total_q if total_q else 0
    score = round(correct_count * marks_per_q, 1)
    pct = round((correct_count / total_q) * 100, 1) if total_q else 0

    wrong_qs = [d["question"] for d in details if not d["is_correct"]]
    unanswered = [d["question"] for d in details if d["student"] == "?"]

    strengths = []
    improvements = []

    if pct >= 80:
        strengths.append(f"Excellent performance — {correct_count}/{total_q} correct")
    elif pct >= 60:
        strengths.append(f"Good attempt — {correct_count}/{total_q} correct")

    if wrong_qs:
        improvements.append(f"Review questions: {', '.join(map(str, wrong_qs))}")
    if unanswered:
        improvements.append(f"Questions not found in answer: {', '.join(map(str, unanswered))} — check handwriting clarity")

    return {
        "score": score,
        "percentage": pct,
        "grade": get_grade(pct),
        "mcq_details": details,
        "correct_count": correct_count,
        "total_questions": total_q,
        "feedback": f"Scored {correct_count} out of {total_q} questions correctly.",
        "strengths": strengths,
        "improvements": improvements,
        "keyword_analysis": {}
    }


# ══════════════════════════════════════════════════════════════════════════════
#  THEORY EVALUATOR
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_theory(student_text: str, reference: str, total_marks: int) -> dict:
    """
    1. Keyword matching (fast, local)
    2. Semantic similarity via sentence-transformers (local, no API)
    3. Combine for final score
    """
    student_lower = student_text.lower()
    ref_lower = reference.lower()

    # Extract keywords from reference — words longer than 3 chars
    stop_words = {"the", "and", "for", "that", "with", "this", "from", "are", "was",
                  "were", "have", "has", "been", "will", "would", "could", "should",
                  "their", "they", "which", "what", "when", "where", "how", "also",
                  "more", "than", "its", "any", "all", "can", "not", "but", "one"}

    ref_words = re.findall(r"\b[a-z]{4,}\b", ref_lower)
    keywords = list(dict.fromkeys([w for w in ref_words if w not in stop_words]))[:30]

    # Keyword match
    matched = [k for k in keywords if k in student_lower]
    missing = [k for k in keywords if k not in student_lower]
    kw_score = (len(matched) / len(keywords)) * 100 if keywords else 0

    # Semantic similarity (if model available)
    sem_score = 0.0
    sem_available = False
    model = load_sentence_model()
    if model:
        try:
            emb_s = model.encode(student_text, convert_to_tensor=True)
            emb_r = model.encode(reference, convert_to_tensor=True)
            sem_score = float(util.cos_sim(emb_s, emb_r)[0][0]) * 100
            sem_available = True
        except Exception:
            sem_score = kw_score  # fallback

    # Combine: 50% keyword, 50% semantic (or 100% keyword if no model)
    if sem_available:
        combined_pct = (kw_score * 0.5) + (sem_score * 0.5)
    else:
        combined_pct = kw_score

    # Word count scoring bonus (penalise extremely short answers)
    wc = len(student_text.split())
    ref_wc = len(reference.split())
    if wc < ref_wc * 0.25:
        combined_pct = min(combined_pct, 40)  # cap at 40% for very short answers

    combined_pct = min(combined_pct, 100)
    score = round((combined_pct / 100) * total_marks, 1)

    # Generate feedback
    strengths = []
    improvements = []

    if matched:
        strengths.append(f"Used {len(matched)} key concept(s): {', '.join(matched[:5])}")
    if sem_score > 70:
        strengths.append("Answer is conceptually well-aligned with the reference")
    if wc >= ref_wc * 0.7:
        strengths.append("Answer length is adequate")

    if missing[:5]:
        improvements.append(f"Missing key concepts: {', '.join(missing[:5])}")
    if sem_score < 50 and sem_available:
        improvements.append("The conceptual coverage could be improved — try to address more aspects of the topic")
    if wc < ref_wc * 0.4:
        improvements.append(f"Answer is too brief ({wc} words). Aim for at least {int(ref_wc * 0.6)} words for full marks")

    ideal_length = f"~{ref_wc} words" if ref_wc > 5 else "Not specified"

    return {
        "score": score,
        "percentage": round(combined_pct, 1),
        "grade": get_grade(combined_pct),
        "keyword_analysis": {
            "total_keywords": len(keywords),
            "matched": matched,
            "missing": missing[:10],
            "keyword_score": round(kw_score, 1)
        },
        "semantic_score": round(sem_score, 1) if sem_available else None,
        "sem_available": sem_available,
        "ideal_length": ideal_length,
        "feedback": f"Keyword match: {len(matched)}/{len(keywords)}. " +
                    (f"Semantic similarity: {sem_score:.0f}%." if sem_available else ""),
        "strengths": strengths,
        "improvements": improvements,
        "mcq_details": []
    }


# ══════════════════════════════════════════════════════════════════════════════
#  CODE EVALUATOR  (uses Groq free LLM)
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_code(student_text: str, topic_description: str, total_marks: int, subject: str = "") -> dict:
    """
    Send the extracted code + topic to Groq (free LLM) for evaluation.
    Returns structured JSON feedback.
    """
    client = get_groq_client()

    prompt = f"""You are a programming instructor evaluating a student's handwritten code answer.

Topic / Task: {topic_description}
Subject: {subject or 'Programming'}
Total Marks: {total_marks}

Student's extracted code (from handwritten image via OCR — may have minor OCR errors):
---
{student_text}
---

Evaluate this code strictly. Return ONLY a valid JSON object with these exact keys:
{{
  "score": <number between 0 and {total_marks}>,
  "percentage": <0-100>,
  "grade": "<A+/A/B/C/D/F>",
  "logic_correct": <true/false>,
  "syntax_issues": ["list of syntax problems found"],
  "logic_issues": ["list of logic problems found"],
  "good_points": ["what the student did correctly"],
  "improvements": ["specific things to fix or improve"],
  "expected_approach": "brief description of the ideal solution approach",
  "ocr_note": "mention if any part seems like OCR noise rather than student mistake",
  "overall_feedback": "2-3 sentence overall assessment"
}}

Be fair about OCR artifacts (characters that look wrong due to scanning). Judge logic and approach primarily.
"""

    try:
        response = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=800,
        )
        raw = response.choices[0].message.content.strip()

        # Extract JSON block
        json_match = re.search(r"\{.*\}", raw, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
        else:
            raise ValueError("No JSON found in response")

        return {
            "score": min(float(data.get("score", 0)), total_marks),
            "percentage": float(data.get("percentage", 0)),
            "grade": data.get("grade", "N/A"),
            "logic_correct": data.get("logic_correct", False),
            "syntax_issues": data.get("syntax_issues", []),
            "logic_issues": data.get("logic_issues", []),
            "good_points": data.get("good_points", []),
            "improvements": data.get("improvements", []),
            "expected_approach": data.get("expected_approach", ""),
            "ocr_note": data.get("ocr_note", ""),
            "overall_feedback": data.get("overall_feedback", ""),
            "feedback": data.get("overall_feedback", ""),
            "strengths": data.get("good_points", []),
            "keyword_analysis": {},
            "mcq_details": [],
            "ai_evaluated": True
        }

    except Exception as e:
        # Fallback: basic keyword/structure check without AI
        return _code_fallback(student_text, topic_description, total_marks, error=str(e))


def _code_fallback(student_text: str, topic: str, total_marks: int, error: str = "") -> dict:
    """Basic code evaluation without AI — checks for code structure indicators."""
    indicators = {
        "has_function": bool(re.search(r"\b(def |function |void |int |class )\b", student_text, re.I)),
        "has_loop": bool(re.search(r"\b(for|while|do)\b", student_text, re.I)),
        "has_condition": bool(re.search(r"\b(if|else|elif|switch|case)\b", student_text, re.I)),
        "has_return": bool(re.search(r"\breturn\b", student_text, re.I)),
        "has_variable": bool(re.search(r"[a-zA-Z_]\w*\s*=\s*\S", student_text)),
    }
    score_pct = (sum(indicators.values()) / len(indicators)) * 100
    score = round((score_pct / 100) * total_marks, 1)

    return {
        "score": score,
        "percentage": round(score_pct, 1),
        "grade": get_grade(score_pct),
        "logic_correct": None,
        "syntax_issues": [],
        "logic_issues": [],
        "good_points": [k for k, v in indicators.items() if v],
        "improvements": ["Add Groq API key for full AI-based code evaluation"],
        "expected_approach": topic,
        "ocr_note": "",
        "overall_feedback": f"Basic structural check only. Add GROQ_API_KEY for full evaluation. Error: {error}",
        "feedback": "Basic structural analysis done. AI evaluation unavailable.",
        "strengths": [k for k, v in indicators.items() if v],
        "keyword_analysis": {},
        "mcq_details": [],
        "ai_evaluated": False
    }


# ══════════════════════════════════════════════════════════════════════════════
#  SHORT ANSWER EVALUATOR
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_short(student_text: str, reference: str, total_marks: int) -> dict:
    """Combines exact match ratio + semantic similarity for short answers."""
    # Use theory evaluator logic — works well for short answers too
    result = evaluate_theory(student_text, reference, total_marks)
    # For short answers, penalise verbose answers (shouldn't be too long)
    wc = len(student_text.split())
    if wc > 150:
        result["improvements"].append("Short answers should be concise — aim for 1-3 sentences")
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def get_grade(percentage: float) -> str:
    if percentage >= 90: return "A+"
    elif percentage >= 80: return "A"
    elif percentage >= 70: return "B"
    elif percentage >= 60: return "C"
    elif percentage >= 50: return "D"
    else: return "F"
