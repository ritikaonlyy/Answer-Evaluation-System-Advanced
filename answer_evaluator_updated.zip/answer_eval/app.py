import streamlit as st
from PIL import Image
import time

from ocr_engine import extract_text_from_image
from evaluator import evaluate_answer
from result_renderer import render_results

st.set_page_config(
    page_title="Answer Evaluator",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1e3a5f;
        text-align: center;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        text-align: center;
        color: #555;
        margin-bottom: 2rem;
        font-size: 1rem;
    }
    .section-card {
        background: #f8f9fc;
        border-radius: 12px;
        padding: 1.5rem;
        border: 1px solid #e0e4ef;
        margin-bottom: 1rem;
    }
    .stButton > button {
        background: linear-gradient(135deg, #1e3a5f, #2e6da4);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.6rem 2rem;
        font-size: 1rem;
        font-weight: 600;
        width: 100%;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #16304f, #245c8c);
    }
    .answer-type-info {
        font-size: 0.82rem;
        color: #888;
        margin-top: 0.3rem;
    }
    .page-badge {
        display: inline-block;
        background: #e8f0fb;
        color: #1e3a5f;
        border-radius: 6px;
        padding: 2px 10px;
        font-size: 0.78rem;
        font-weight: 600;
        margin-bottom: 4px;
    }
    .ocr-page-header {
        font-size: 0.9rem;
        font-weight: 600;
        color: #1e3a5f;
        margin-top: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-header">📝 Answer Evaluation System</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Upload up to 10 handwritten answer images and a reference to get detailed AI-powered feedback</div>', unsafe_allow_html=True)

# ── STEP 1: Answer type selection ──────────────────────────────────────────────
col_type, col_spacer = st.columns([2, 1])
with col_type:
    answer_type = st.selectbox(
        "📚 What type of answer is this?",
        ["Theory / Descriptive", "MCQ (Multiple Choice)", "Code / Programming", "Short Answer"],
        help="Select the type so the evaluator uses the right strategy."
    )

st.divider()

# ── STEP 2: Upload panels ──────────────────────────────────────────────────────
left, right = st.columns(2, gap="large")

with left:
    st.markdown("### 🖊️ Student's Answer")
    st.markdown(
        '<p class="answer-type-info">Upload up to <strong>10</strong> photos or scans of the handwritten answer sheet '
        '(e.g. multiple pages). Pages are read in order and combined automatically.</p>',
        unsafe_allow_html=True
    )
    student_files = st.file_uploader(
        "Upload handwritten answer images",
        type=["jpg", "jpeg", "png", "webp", "bmp"],
        accept_multiple_files=True,
        key="student_upload",
        label_visibility="collapsed"
    )

    # Enforce 10-image limit and show thumbnails
    if student_files:
        if len(student_files) > 10:
            st.warning("⚠️ Maximum 10 images allowed. Only the first 10 will be processed.")
            student_files = student_files[:10]

        total = len(student_files)
        st.markdown(f"**{total} page{'s' if total > 1 else ''} uploaded**")

        # Show thumbnails in a responsive grid (up to 5 per row)
        cols_per_row = min(total, 5)
        rows = [student_files[i:i + cols_per_row] for i in range(0, total, cols_per_row)]
        for row_files in rows:
            thumb_cols = st.columns(len(row_files))
            for col, f in zip(thumb_cols, row_files):
                with col:
                    img = Image.open(f)
                    page_num = student_files.index(f) + 1
                    st.markdown(f'<div class="page-badge">Page {page_num}</div>', unsafe_allow_html=True)
                    st.image(img, use_container_width=True)

with right:
    st.markdown("### 📋 Reference / Instructions")

    if answer_type == "MCQ (Multiple Choice)":
        st.markdown('<p class="answer-type-info">Paste the correct options, e.g.  1-A  2-C  3-B  4-D</p>', unsafe_allow_html=True)
        reference_text = st.text_area(
            "MCQ answer key",
            placeholder="1-A\n2-C\n3-B\n4-D\n5-A",
            height=200,
            label_visibility="collapsed"
        )

    elif answer_type == "Theory / Descriptive":
        st.markdown('<p class="answer-type-info">Enter keywords that MUST appear, or paste the model answer</p>', unsafe_allow_html=True)
        reference_text = st.text_area(
            "Keywords / model answer",
            placeholder="e.g. photosynthesis, chlorophyll, light energy, glucose, oxygen\n\nOR paste a full model answer here.",
            height=200,
            label_visibility="collapsed"
        )

    elif answer_type == "Code / Programming":
        st.markdown('<p class="answer-type-info">Just describe the topic / task. The AI will generate evaluation criteria automatically.</p>', unsafe_allow_html=True)
        reference_text = st.text_area(
            "Topic description",
            placeholder="e.g. Write a Python function that reverses a string using slicing.\n\nOR: Implement a linked list with insert and delete operations in C++.",
            height=200,
            label_visibility="collapsed"
        )

    else:  # Short Answer
        st.markdown('<p class="answer-type-info">Provide the correct answer or key points expected</p>', unsafe_allow_html=True)
        reference_text = st.text_area(
            "Correct answer / key points",
            placeholder="Enter the correct answer or expected key points here.",
            height=200,
            label_visibility="collapsed"
        )

    subject = st.text_input("Subject (optional)", placeholder="e.g. Biology, Python Programming, History")
    total_marks = st.number_input("Total marks for this question", min_value=1, max_value=100, value=10)

st.divider()

# ── STEP 3: Evaluate button ────────────────────────────────────────────────────
_, btn_col, _ = st.columns([1, 2, 1])
with btn_col:
    evaluate_clicked = st.button("🔍 Evaluate Answer", use_container_width=True)

if evaluate_clicked:
    if not student_files:
        st.error("⚠️ Please upload at least one answer image.")
    elif not reference_text.strip():
        st.error("⚠️ Please fill in the reference / instructions section.")
    else:
        st.divider()
        st.markdown("## 📊 Evaluation Results")

        # ── OCR: process each page ──────────────────────────────────────────
        all_pages_text = []
        ocr_times = []

        progress = st.progress(0, text="🔍 Extracting text from images...")

        for idx, f in enumerate(student_files):
            page_num = idx + 1
            progress.progress(
                int((idx / len(student_files)) * 100),
                text=f"🔍 Extracting text from page {page_num} of {len(student_files)}..."
            )
            t0 = time.time()
            img = Image.open(f)
            text = extract_text_from_image(img)
            elapsed = round(time.time() - t0, 2)
            all_pages_text.append((page_num, text, elapsed))
            ocr_times.append(elapsed)

        progress.progress(100, text="✅ Text extraction complete!")
        time.sleep(0.4)
        progress.empty()

        # ── Show per-page extracted text ────────────────────────────────────
        with st.expander(
            f"📄 Extracted Text from {len(student_files)} Page{'s' if len(student_files) > 1 else ''}",
            expanded=False
        ):
            for page_num, page_text, elapsed in all_pages_text:
                st.markdown(f'<div class="ocr-page-header">Page {page_num}</div>', unsafe_allow_html=True)
                st.text_area(
                    f"page_{page_num}",
                    page_text if page_text.strip() else "[No text extracted from this page]",
                    height=120,
                    disabled=True,
                    label_visibility="collapsed"
                )
                st.caption(f"⚡ Extracted in {elapsed}s")
            total_ocr = round(sum(ocr_times), 2)
            st.caption(f"🕐 Total OCR time: {total_ocr}s across {len(student_files)} page(s)")

        # ── Combine all pages into one text block ───────────────────────────
        combined_text = "\n\n--- Page Break ---\n\n".join(
            f"[Page {num}]\n{text}" for num, text, _ in all_pages_text
        )

        # Check that at least one page has usable text
        any_text = any(t.strip() for _, t, _ in all_pages_text)

        if not any_text:
            st.error("❌ Could not extract any text from the uploaded images. Please upload clearer photos with good lighting.")
        else:
            # Warn about empty pages
            empty_pages = [num for num, t, _ in all_pages_text if not t.strip()]
            if empty_pages:
                st.warning(
                    f"⚠️ No text could be extracted from page{'s' if len(empty_pages) > 1 else ''} "
                    f"{', '.join(map(str, empty_pages))}. These pages were skipped."
                )

            # ── Evaluate combined text ──────────────────────────────────────
            with st.spinner("🤖 Analysing and scoring the combined answer..."):
                results = evaluate_answer(
                    student_text=combined_text,
                    reference=reference_text,
                    answer_type=answer_type,
                    subject=subject,
                    total_marks=total_marks
                )

            render_results(results, combined_text, total_marks, answer_type)
