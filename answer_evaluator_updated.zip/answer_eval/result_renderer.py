"""
Result Renderer
---------------
Renders the detailed evaluation results in Streamlit.
"""

import streamlit as st
import math


# ── Grade colour map ───────────────────────────────────────────────────────────
GRADE_COLORS = {
    "A+": "#1a7a2e",
    "A":  "#2e9e3f",
    "B":  "#2e7cb8",
    "C":  "#c8a000",
    "D":  "#d46b00",
    "F":  "#c0392b",
    "N/A": "#888"
}


def grade_badge(grade: str) -> str:
    color = GRADE_COLORS.get(grade, "#888")
    return f"""<div style="display:inline-block;background:{color};color:white;
    font-size:2rem;font-weight:700;padding:0.4rem 1.4rem;border-radius:10px;
    text-align:center;">{grade}</div>"""


def score_bar(score: float, total: float):
    pct = min((score / total) * 100, 100) if total else 0
    color = "#1a7a2e" if pct >= 70 else ("#c8a000" if pct >= 50 else "#c0392b")
    st.markdown(f"""
    <div style="background:#eee;border-radius:8px;height:22px;width:100%;margin-bottom:0.5rem">
        <div style="background:{color};width:{pct:.1f}%;height:100%;border-radius:8px;
        display:flex;align-items:center;padding-left:8px;color:white;font-weight:600;font-size:0.85rem">
            {pct:.0f}%
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_results(results: dict, extracted_text: str, total_marks: int, answer_type: str):
    """Main entry point — renders the full result dashboard."""

    score = results.get("score", 0)
    percentage = results.get("percentage", 0)
    grade = results.get("grade", "N/A")

    # ── TOP SUMMARY ROW ────────────────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown("**Score**")
        st.markdown(f"<h2 style='margin:0;color:#1e3a5f'>{score} / {total_marks}</h2>", unsafe_allow_html=True)

    with c2:
        st.markdown("**Grade**")
        st.markdown(grade_badge(grade), unsafe_allow_html=True)

    with c3:
        st.markdown("**Word Count**")
        wc = results.get("word_count", len(extracted_text.split()))
        st.markdown(f"<h2 style='margin:0;color:#1e3a5f'>{wc}</h2>", unsafe_allow_html=True)

    with c4:
        st.markdown("**Answer Type**")
        st.markdown(f"<p style='font-weight:600;color:#555;margin-top:0.3rem'>{answer_type}</p>", unsafe_allow_html=True)

    st.markdown("")
    score_bar(score, total_marks)

    st.divider()

    # ── ROUTE TO TYPE-SPECIFIC RENDERER ───────────────────────────────────────
    if answer_type == "MCQ (Multiple Choice)":
        _render_mcq(results)
    elif answer_type in ["Theory / Descriptive", "Short Answer"]:
        _render_theory(results)
    elif answer_type == "Code / Programming":
        _render_code(results)

    # ── COMMON: STRENGTHS & IMPROVEMENTS ──────────────────────────────────────
    st.divider()
    col_s, col_i = st.columns(2)

    with col_s:
        st.markdown("### ✅ Strengths")
        strengths = results.get("strengths", [])
        if strengths:
            for s in strengths:
                st.success(s)
        else:
            st.info("No specific strengths identified.")

    with col_i:
        st.markdown("### 🔧 What to Improve")
        improvements = results.get("improvements", [])
        if improvements:
            for imp in improvements:
                st.warning(imp)
        else:
            st.success("No major improvements needed!")

    # ── GRADING BASIS ─────────────────────────────────────────────────────────
    st.divider()
    st.markdown("### 📐 Grading Basis")
    _render_grading_basis(results, answer_type)

    # ── GRADE SCALE ───────────────────────────────────────────────────────────
    with st.expander("📊 Grade Scale Reference"):
        cols = st.columns(6)
        scale = [("A+","90-100%"),("A","80-89%"),("B","70-79%"),("C","60-69%"),("D","50-59%"),("F","<50%")]
        for col, (g, r) in zip(cols, scale):
            c = GRADE_COLORS[g]
            col.markdown(f"<div style='background:{c};color:white;border-radius:6px;padding:0.4rem;text-align:center'>"
                         f"<b>{g}</b><br><small>{r}</small></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
#  MCQ DETAIL RENDERER
# ══════════════════════════════════════════════════════════════════════════════

def _render_mcq(results: dict):
    details = results.get("mcq_details", [])
    if not details:
        st.warning(results.get("error", "No MCQ details available."))
        return

    correct = results.get("correct_count", 0)
    total_q = results.get("total_questions", len(details))

    st.markdown(f"### 📋 Question-by-Question Breakdown")
    st.caption(f"**{correct} correct out of {total_q} questions**")

    # Grid display
    cols_per_row = 5
    rows = math.ceil(len(details) / cols_per_row)

    for row_i in range(rows):
        cols = st.columns(cols_per_row)
        for col_i in range(cols_per_row):
            idx = row_i * cols_per_row + col_i
            if idx < len(details):
                d = details[idx]
                with cols[col_i]:
                    bg = "#d4edda" if d["is_correct"] else "#f8d7da"
                    icon = "✅" if d["is_correct"] else "❌"
                    st.markdown(
                        f"<div style='background:{bg};border-radius:8px;padding:0.5rem;text-align:center;margin-bottom:0.5rem'>"
                        f"<b>Q{d['question']}</b><br>"
                        f"Your: <b>{d['student']}</b><br>"
                        f"Correct: <b>{d['correct']}</b><br>{icon}</div>",
                        unsafe_allow_html=True
                    )


# ══════════════════════════════════════════════════════════════════════════════
#  THEORY DETAIL RENDERER
# ══════════════════════════════════════════════════════════════════════════════

def _render_theory(results: dict):
    kw = results.get("keyword_analysis", {})
    sem_score = results.get("semantic_score")
    sem_available = results.get("sem_available", False)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### 🔑 Keyword Analysis")
        matched = kw.get("matched", [])
        missing = kw.get("missing", [])
        total_kw = kw.get("total_keywords", 0)
        kw_score = kw.get("keyword_score", 0)

        if total_kw:
            st.metric("Keywords found", f"{len(matched)} / {total_kw}", f"{kw_score:.0f}%")

            if matched:
                st.markdown("**✅ Keywords present:**")
                for kw_word in matched:
                    st.markdown(
                        f"<span style='background:#d4edda;border-radius:4px;padding:2px 8px;margin:2px;display:inline-block'>{kw_word}</span>",
                        unsafe_allow_html=True
                    )
                st.markdown("")

            if missing:
                st.markdown("**❌ Keywords missing:**")
                for kw_word in missing:
                    st.markdown(
                        f"<span style='background:#f8d7da;border-radius:4px;padding:2px 8px;margin:2px;display:inline-block'>{kw_word}</span>",
                        unsafe_allow_html=True
                    )
        else:
            st.info("No keywords extracted from reference.")

    with col2:
        st.markdown("### 🧠 Semantic Analysis")
        if sem_available and sem_score is not None:
            st.metric("Semantic similarity", f"{sem_score:.1f}%")
            if sem_score >= 75:
                st.success("High conceptual alignment with the reference answer.")
            elif sem_score >= 50:
                st.warning("Moderate alignment — some concepts missing or off-topic.")
            else:
                st.error("Low alignment — answer may be missing core concepts.")

            # Interpretation
            st.markdown("---")
            st.caption("**What semantic score means:**")
            st.caption("Measures how conceptually close the student's answer is to the reference, even if different words are used. A score of 70%+ is generally good.")
        else:
            st.info("Semantic analysis not available. Install `sentence-transformers` for this feature.")

    # Answer length analysis
    st.markdown("### 📏 Answer Length Analysis")
    wc = results.get("word_count", 0)
    ideal = results.get("ideal_length", "Not specified")

    lc1, lc2, lc3 = st.columns(3)
    lc1.metric("Student word count", wc)
    lc2.metric("Ideal length", ideal)
    char_count = results.get("char_count", len(results.get("student_text", "")))
    lc3.metric("Character count", char_count)

    if wc < 20:
        st.error("⚠️ Answer is very short. May indicate incomplete response or OCR issues.")
    elif wc < 50:
        st.warning("Answer is fairly brief. Consider elaborating more.")
    else:
        st.success("Answer length is reasonable.")


# ══════════════════════════════════════════════════════════════════════════════
#  CODE DETAIL RENDERER
# ══════════════════════════════════════════════════════════════════════════════

def _render_code(results: dict):
    ai_evaluated = results.get("ai_evaluated", False)

    if ai_evaluated:
        st.markdown("### 🤖 AI Code Evaluation")
        st.success(results.get("overall_feedback", ""))

        col1, col2 = st.columns(2)

        with col1:
            logic_ok = results.get("logic_correct")
            if logic_ok is True:
                st.success("✅ Logic is correct")
            elif logic_ok is False:
                st.error("❌ Logic has issues")
            else:
                st.info("Logic correctness undetermined")

            syntax_issues = results.get("syntax_issues", [])
            if syntax_issues:
                st.markdown("**🔴 Syntax issues:**")
                for issue in syntax_issues:
                    st.markdown(f"- {issue}")
            else:
                st.markdown("**✅ No syntax issues detected**")

            logic_issues = results.get("logic_issues", [])
            if logic_issues:
                st.markdown("**🟠 Logic issues:**")
                for issue in logic_issues:
                    st.markdown(f"- {issue}")

        with col2:
            good = results.get("good_points", [])
            if good:
                st.markdown("**✅ What you did well:**")
                for g in good:
                    st.markdown(f"- {g}")

            improvements = results.get("improvements", [])
            if improvements:
                st.markdown("**🔧 Specific fixes needed:**")
                for imp in improvements:
                    st.markdown(f"- {imp}")

        expected = results.get("expected_approach", "")
        if expected:
            st.markdown("### 💡 Expected Approach")
            st.info(expected)

        ocr_note = results.get("ocr_note", "")
        if ocr_note:
            st.caption(f"📷 OCR note: {ocr_note}")
    else:
        st.warning("⚠️ Full AI evaluation not available — showing basic structural check.")
        st.markdown("**Add your Groq API key to enable full code evaluation.**")
        good = results.get("good_points", [])
        if good:
            st.markdown("**Code structure elements found:**")
            for g in good:
                st.markdown(f"- {g}")


# ══════════════════════════════════════════════════════════════════════════════
#  GRADING BASIS PANEL
# ══════════════════════════════════════════════════════════════════════════════

def _render_grading_basis(results: dict, answer_type: str):
    if answer_type == "MCQ (Multiple Choice)":
        st.markdown("""
        | Component | Weight | Details |
        |-----------|--------|---------|
        | Correct answers | 100% | Each correct option gets equal marks |
        | Partial credit | ❌ | No partial credit for MCQs |
        """)

    elif answer_type in ["Theory / Descriptive", "Short Answer"]:
        sem_available = results.get("sem_available", False)
        if sem_available:
            st.markdown("""
            | Component | Weight | Details |
            |-----------|--------|---------|
            | Keyword matching | 50% | Presence of key concepts from reference |
            | Semantic similarity | 50% | Conceptual closeness using AI embeddings |
            | Length penalty | Modifier | Answers <25% of reference length are capped at 40% |
            """)
        else:
            st.markdown("""
            | Component | Weight | Details |
            |-----------|--------|---------|
            | Keyword matching | 100% | Presence of key concepts from reference |
            | Length penalty | Modifier | Answers <25% of reference length are capped at 40% |
            
            > Install `sentence-transformers` to enable semantic similarity scoring.
            """)

    elif answer_type == "Code / Programming":
        if results.get("ai_evaluated"):
            st.markdown("""
            | Component | Weight | Details |
            |-----------|--------|---------|
            | Logic correctness | 50% | Does the code solve the stated problem? |
            | Syntax quality | 25% | Correct language syntax and structure |
            | Code style & approach | 25% | Clarity, efficiency, best practices |
            
            > Evaluated by Groq LLaMA3 — OCR noise is accounted for by the model.
            """)
        else:
            st.markdown("""
            | Component | Details |
            |-----------|---------|
            | Structural checks | Presence of functions, loops, conditions, variables |
            
            > Add Groq API key for full AI-based grading.
            """)
