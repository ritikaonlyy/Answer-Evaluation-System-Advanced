"""
OCR Engine
----------
Uses Tesseract (free, offline) with OpenCV preprocessing for speed & accuracy.
Falls back gracefully if dependencies are missing.
"""

import cv2
import numpy as np
import pytesseract
from PIL import Image


def preprocess_image(pil_img: Image.Image) -> np.ndarray:
    """
    Fast preprocessing pipeline:
    1. Convert to grayscale
    2. Resize if too small (Tesseract struggles under ~300 DPI)
    3. Denoise
    4. Adaptive threshold for better contrast on handwriting
    """
    img = np.array(pil_img.convert("RGB"))
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # Upscale if the image is small — Tesseract needs at least ~1000px on the long side
    h, w = gray.shape
    if max(h, w) < 1200:
        scale = 1200 / max(h, w)
        gray = cv2.resize(gray, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_CUBIC)

    # Denoise — fast median blur
    gray = cv2.medianBlur(gray, 3)

    # Adaptive threshold — works well for uneven lighting on handwritten sheets
    thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31, 10
    )

    return thresh


def extract_text_from_image(pil_img: Image.Image) -> str:
    """
    Extract text from a PIL image using Tesseract OCR.
    Returns the extracted string. Empty string on failure.
    """
    try:
        processed = preprocess_image(pil_img)

        # PSM 6 = assume a single uniform block of text (good for answer sheets)
        # OEM 3 = default Tesseract + LSTM engine (fastest + most accurate)
        custom_config = r"--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,;:!?()[]{}+-=*/\\<>@#$%^&_'\"\n "

        text = pytesseract.image_to_string(processed, config=custom_config)
        return text.strip()

    except Exception as e:
        return f"[OCR Error: {str(e)}. Make sure Tesseract is installed — see setup instructions.]"
